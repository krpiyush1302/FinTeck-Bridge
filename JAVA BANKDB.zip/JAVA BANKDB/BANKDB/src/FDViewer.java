import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class FDViewer extends JFrame {
    private JTable table;
    private String accountNumber;

    public FDViewer(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("My Fixed Deposits");
        setSize(600, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadFDData();
        setVisible(true);
    }

    private void loadFDData() {
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "FD Amount", "Start Date", "Tenure (Months)", "Interest Rate", "Maturity Date"
        });

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM FixedDeposits WHERE account_number = ?");
            ps.setString(1, accountNumber);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getDouble("amount"),
                        rs.getDate("start_date"),
                        rs.getInt("tenure_months"),
                        rs.getDouble("interest_rate") + " %",
                        rs.getDate("maturity_date")
                });
            }

            table.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading FDs: " + e.getMessage());
        }
    }
}
