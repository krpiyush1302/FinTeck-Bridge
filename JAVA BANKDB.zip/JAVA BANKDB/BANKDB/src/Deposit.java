import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Deposit extends JFrame {
    private String accountNumber;
    private JTextField amountField;
    private Dashboard dashboard; // ✅ Reference to Dashboard

    // ✅ Constructor now accepts Dashboard
    public Deposit(String accountNumber, Dashboard dashboard) {
        this.accountNumber = accountNumber;
        this.dashboard = dashboard;

        setTitle("Deposit Money");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Enter amount to deposit:"));
        amountField = new JTextField();
        panel.add(amountField);

        JButton depositBtn = new JButton("Deposit");
        depositBtn.addActionListener(e -> performDeposit());
        panel.add(depositBtn);

        add(panel);
        setVisible(true);
    }

    private void performDeposit() {
        try {
            double amount = Double.parseDouble(amountField.getText());

            try (Connection con = DBConnection.getConnection()) {
                // Update balance
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE Users SET balance = balance + ? WHERE account_number = ?");
                ps.setDouble(1, amount);
                ps.setString(2, accountNumber);
                ps.executeUpdate();

                // Add transaction
                PreparedStatement tr = con.prepareStatement(
                        "INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, 'Deposit', ?, ?)");
                tr.setString(1, accountNumber);
                tr.setDouble(2, amount);
                tr.setString(3, "Money deposited by user");
                tr.executeUpdate();

                // ✅ Update dashboard balance
                if (dashboard != null) {
                    dashboard.updateBalance();
                }

                JOptionPane.showMessageDialog(this, "Amount Deposited Successfully!");
                this.dispose();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input or error: " + ex.getMessage());
        }
    }
}
