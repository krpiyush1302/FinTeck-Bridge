import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FDApplication extends JFrame {
    private JTextField amountField, tenureField;
    private JButton applyBtn;
    private String accountNumber;
    private Runnable refreshCallback; // ✅ New field

    public FDApplication(String accountNumber,Runnable refreshCallback) {
        this.accountNumber = accountNumber;
        this.refreshCallback = refreshCallback;

        setTitle("Fixed Deposit Application");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("FD Amount (₹):"));
        amountField = new JTextField();
        add(amountField);

        add(new JLabel("Tenure (months):"));
        tenureField = new JTextField();
        add(tenureField);

        applyBtn = new JButton("Apply FD");
        applyBtn.addActionListener(e -> applyFD());
        add(new JLabel(""));
        add(applyBtn);

        setVisible(true);
    }

    private void applyFD() {
        try (Connection con = DBConnection.getConnection()) {
            double amount = Double.parseDouble(amountField.getText());
            int tenure = Integer.parseInt(tenureField.getText());
            double interestRate = 6.5; // Set by bank

            // Check balance
            PreparedStatement check = con.prepareStatement("SELECT balance FROM Users WHERE account_number = ?");
            check.setString(1, accountNumber);
            ResultSet rs = check.executeQuery();
            if (rs.next() && rs.getDouble("balance") >= amount) {
                double balance = rs.getDouble("balance");

                // Deduct balance
                PreparedStatement updateBal = con.prepareStatement("UPDATE Users SET balance = balance - ? WHERE account_number = ?");
                updateBal.setDouble(1, amount);
                updateBal.setString(2, accountNumber);
                updateBal.executeUpdate();

                // Calculate maturity amount
                LocalDate start = LocalDate.now();
                LocalDate end = start.plusMonths(tenure);
                double maturityAmount = amount + (amount * interestRate * tenure / 1200); // Simple interest

                // Insert FD record
                PreparedStatement ps = con.prepareStatement("INSERT INTO FixedDeposits (account_number, amount, tenure_months, interest_rate, start_date, maturity_amount, maturity_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
                ps.setString(1, accountNumber);
                ps.setDouble(2, amount);
                ps.setInt(3, tenure);
                ps.setDouble(4, interestRate);
                ps.setDate(5, Date.valueOf(start));
                ps.setDouble(6, maturityAmount);
                ps.setDate(7, Date.valueOf(end));
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "FD Created Successfully!\nMaturity Amount: ₹" + maturityAmount);
                if (refreshCallback != null) refreshCallback.run(); // ✅ Trigger balance update
                dispose();

            } else {
                JOptionPane.showMessageDialog(this, "Insufficient balance.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
