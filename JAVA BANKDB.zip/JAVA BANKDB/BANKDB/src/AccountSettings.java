import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AccountSettings extends JFrame {
    private JTextField phoneField, addressField, secondaryEmailField;
    private JPasswordField currentPassField, newPassField;
    private String accountNumber;

    public AccountSettings(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("Account Settings");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Current Password:"));
        currentPassField = new JPasswordField();
        panel.add(currentPassField);

        panel.add(new JLabel("New Password:"));
        newPassField = new JPasswordField();
        panel.add(newPassField);

        panel.add(new JLabel("Phone Number:"));
        phoneField = new JTextField();
        panel.add(phoneField);

        panel.add(new JLabel("Address:"));
        addressField = new JTextField();
        panel.add(addressField);

        panel.add(new JLabel("Secondary Email:"));
        secondaryEmailField = new JTextField();
        panel.add(secondaryEmailField);

        JButton updateBtn = new JButton("Update Settings");
        updateBtn.setBackground(new Color(0, 120, 215));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.addActionListener(e -> updateAccount());
        panel.add(new JLabel(""));
        panel.add(updateBtn);

        add(panel);
        setVisible(true);
    }

    private void updateAccount() {
        String currentPass = new String(currentPassField.getPassword());
        String newPass = new String(newPassField.getPassword());
        String phone = phoneField.getText();
        String address = addressField.getText();
        String email = secondaryEmailField.getText();

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement checkPass = con.prepareStatement("SELECT * FROM Users WHERE account_number=? AND password=?");
            checkPass.setString(1, accountNumber);
            checkPass.setString(2, currentPass);
            ResultSet rs = checkPass.executeQuery();

            if (rs.next()) {
                PreparedStatement update = con.prepareStatement("UPDATE Users SET password=?, phone=?, address=?, secondary_email=? WHERE account_number=?");
                update.setString(1, newPass);
                update.setString(2, phone);
                update.setString(3, address);
                update.setString(4, email);
                update.setString(5, accountNumber);

                int rows = update.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Settings updated successfully!");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Update failed.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect current password.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}
