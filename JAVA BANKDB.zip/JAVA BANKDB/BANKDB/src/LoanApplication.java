import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DecimalFormat;

public class LoanApplication extends JFrame {
    private JComboBox<String> loanTypeBox;
    private JTextField amountField, tenureField, emiField;
    private JButton applyBtn, calculateBtn;
    private String accountNumber;
    private final DecimalFormat df = new DecimalFormat("#.##");

    public LoanApplication(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("Apply for Loan");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel typeLabel = new JLabel("Loan Type:");
        loanTypeBox = new JComboBox<>(new String[] {"Personal", "Home", "Education", "Car"});

        JLabel amountLabel = new JLabel("Loan Amount (₹):");
        amountField = new JTextField();

        JLabel tenureLabel = new JLabel("Tenure (months):");
        tenureField = new JTextField();

        JLabel emiLabel = new JLabel("Estimated EMI (₹):");
        emiField = new JTextField();
        emiField.setEditable(false);

        calculateBtn = new JButton("Calculate EMI");
        calculateBtn.addActionListener(e -> calculateEMI());

        applyBtn = new JButton("Apply for Loan");
        applyBtn.addActionListener(e -> applyLoan());

        setLayout(new GridLayout(7, 2, 10, 10));
        add(typeLabel); add(loanTypeBox);
        add(amountLabel); add(amountField);
        add(tenureLabel); add(tenureField);
        add(emiLabel); add(emiField);
        add(calculateBtn); add(new JLabel());
        add(applyBtn);

        setVisible(true);
    }

    private void calculateEMI() {
        try {
            double principal = Double.parseDouble(amountField.getText());
            int tenure = Integer.parseInt(tenureField.getText());
            double rate = getInterestRate((String) loanTypeBox.getSelectedItem());

            double monthlyRate = rate / (12 * 100);
            double emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) /
                    (Math.pow(1 + monthlyRate, tenure) - 1);

            emiField.setText(df.format(emi));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Please enter valid amount and tenure.");
        }
    }

    private double getInterestRate(String loanType) {
        return switch (loanType) {
            case "Home" -> 7.5;
            case "Education" -> 5.0;
            case "Car" -> 8.0;
            default -> 10.5; // Personal Loan
        };
    }

    private void applyLoan() {
        try {
            double principal = Double.parseDouble(amountField.getText());
            int tenure = Integer.parseInt(tenureField.getText());
            double rate = getInterestRate((String) loanTypeBox.getSelectedItem());
            double emi = Double.parseDouble(emiField.getText());

            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO Loans (account_number, loan_type, amount, tenure_months, interest_rate, emi, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, accountNumber);
            ps.setString(2, (String) loanTypeBox.getSelectedItem());
            ps.setDouble(3, principal);
            ps.setInt(4, tenure);
            ps.setDouble(5, rate);
            ps.setDouble(6, emi);
            ps.setString(7, "Pending");
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Loan application submitted successfully! Status: Pending");
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}
