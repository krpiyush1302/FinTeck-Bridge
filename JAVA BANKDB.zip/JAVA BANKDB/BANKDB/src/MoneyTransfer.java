import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MoneyTransfer extends JFrame {
    private final String senderAccount;

    public MoneyTransfer(String senderAccount) {
        this.senderAccount = senderAccount;
        setTitle("Money Transfer - NEFT / IMPS / RTGS");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(7, 2, 10, 10));

        JLabel toAccLabel = new JLabel("Recipient Account Number:");
        JTextField toAccField = new JTextField();

        JLabel amtLabel = new JLabel("Amount (₹):");
        JTextField amtField = new JTextField();

        JLabel modeLabel = new JLabel("Transfer Mode:");
        JPanel modePanel = new JPanel(new FlowLayout());

        JRadioButton neftBtn = new JRadioButton("NEFT");
        JRadioButton impsBtn = new JRadioButton("IMPS");
        JRadioButton rtgsBtn = new JRadioButton("RTGS");

        ButtonGroup modeGroup = new ButtonGroup();
        modeGroup.add(neftBtn);
        modeGroup.add(impsBtn);
        modeGroup.add(rtgsBtn);

        modePanel.add(neftBtn);
        modePanel.add(impsBtn);
        modePanel.add(rtgsBtn);

        JButton transferBtn = new JButton("Transfer");
        JLabel statusLabel = new JLabel("");

        transferBtn.addActionListener(e -> {
            String recipient = toAccField.getText().trim();
            String amountText = amtField.getText().trim();
            String mode = neftBtn.isSelected() ? "NEFT" :
                    impsBtn.isSelected() ? "IMPS" :
                            rtgsBtn.isSelected() ? "RTGS" : "";

            if (recipient.isEmpty() || amountText.isEmpty() || mode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required and mode must be selected.");
                return;
            }

            try {
                double amount = Double.parseDouble(amountText);
                if (amount <= 0) throw new NumberFormatException();

                processTransfer(senderAccount, recipient, amount, mode);
                statusLabel.setText("✅ " + mode + " Transfer Successful!");
                toAccField.setText("");
                amtField.setText("");
                modeGroup.clearSelection();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter a valid amount.");
            }
        });

        add(toAccLabel);
        add(toAccField);
        add(amtLabel);
        add(amtField);
        add(modeLabel);
        add(modePanel);
        add(new JLabel()); // spacer
        add(transferBtn);
        add(new JLabel()); // spacer
        add(statusLabel);

        setVisible(true);
    }

    private void processTransfer(String fromAcc, String toAcc, double amount, String mode) {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            PreparedStatement psCheck = con.prepareStatement("SELECT balance FROM Users WHERE account_number = ?");
            psCheck.setString(1, fromAcc);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    JOptionPane.showMessageDialog(this, "Insufficient balance.");
                    return;
                }
            } else {
                JOptionPane.showMessageDialog(this, "Sender account not found.");
                return;
            }

            // Deduct from sender
            PreparedStatement psDeduct = con.prepareStatement("UPDATE Users SET balance = balance - ? WHERE account_number = ?");
            psDeduct.setDouble(1, amount);
            psDeduct.setString(2, fromAcc);
            psDeduct.executeUpdate();

            // Add to receiver
            PreparedStatement psCredit = con.prepareStatement("UPDATE Users SET balance = balance + ? WHERE account_number = ?");
            psCredit.setDouble(1, amount);
            psCredit.setString(2, toAcc);
            int rowsUpdated = psCredit.executeUpdate();

            if (rowsUpdated == 0) {
                con.rollback();
                JOptionPane.showMessageDialog(this, "Recipient account not found.");
                return;
            }

            // Insert transaction for sender
            PreparedStatement psTxn1 = con.prepareStatement("INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, ?, ?, ?)");
            psTxn1.setString(1, fromAcc);
            psTxn1.setString(2, "Transfer");
            psTxn1.setDouble(3, -amount);
            psTxn1.setString(4, "To " + toAcc + " via " + mode);
            psTxn1.executeUpdate();

            // Insert transaction for receiver
            PreparedStatement psTxn2 = con.prepareStatement("INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, ?, ?, ?)");
            psTxn2.setString(1, toAcc);
            psTxn2.setString(2, "Credit");
            psTxn2.setDouble(3, amount);
            psTxn2.setString(4, "From " + fromAcc + " via " + mode);
            psTxn2.executeUpdate();

            con.commit();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
