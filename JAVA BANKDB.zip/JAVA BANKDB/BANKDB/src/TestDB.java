public class TestDB {
    public static void main(String[] args) {
        if (DBConnection.getConnection() != null) {
            System.out.println("✅ Connected to SQL Server using Windows Authentication!");
        } else {
            System.out.println("❌ Connection failed.");
        }
    }
}
