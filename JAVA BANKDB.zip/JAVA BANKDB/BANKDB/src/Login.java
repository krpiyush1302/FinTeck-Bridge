import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JCheckBox showPass;
    private JButton loginBtn, signupBtn;

    public Login() {
        setTitle("FinTechBank - Login");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Background gradient
        JPanel background = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(220, 235, 250);
                Color color2 = new Color(170, 210, 240);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        background.setLayout(new GridBagLayout());

        // Card panel
        JPanel card = new JPanel(new GridBagLayout());
        card.setPreferredSize(new Dimension(380, 320));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));
        card.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("FinTechBank Login", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(0, 102, 204));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        card.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;

        JLabel userLabel = new JLabel("Email / Account No:");
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        card.add(userLabel, gbc);

        userField = new JTextField();
        userField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 1;
        card.add(userField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;

        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        card.add(passLabel, gbc);

        passField = new JPasswordField();
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 1;
        card.add(passField, gbc);

        // Show password checkbox
        showPass = new JCheckBox("Show Password");
        showPass.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        showPass.setBackground(Color.WHITE);
        showPass.addActionListener(e -> {
            if (showPass.isSelected()) {
                passField.setEchoChar((char) 0);
            } else {
                passField.setEchoChar('•');
            }
        });
        gbc.gridx = 1;
        gbc.gridy++;
        card.add(showPass, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;

        loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginBtn.setBackground(new Color(0, 120, 215));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.addActionListener(e -> checkLogin());
        card.add(loginBtn, gbc);

        gbc.gridy++;

        JPanel signupPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        signupPanel.setBackground(Color.WHITE);

        JLabel signupText = new JLabel("New user?");
        signupText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        signupPanel.add(signupText);

        signupBtn = new JButton("Sign up");
        signupBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        signupBtn.setBackground(new Color(34, 139, 34));
        signupBtn.setForeground(Color.WHITE);
        signupBtn.setFocusPainted(false);
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupBtn.addActionListener(e -> {
            dispose();
            new Signup();
        });

        signupPanel.add(signupBtn);
        card.add(signupPanel, gbc);

        background.add(card);
        add(background);
        setVisible(true);
    }

    private void checkLogin() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();

        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM Users WHERE (email = ? OR account_number = ?) AND password = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, username);
            ps.setString(3, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String userName = rs.getString("full_name");
                String accNo = rs.getString("account_number");
                JOptionPane.showMessageDialog(this, "Welcome, " + userName + "!");
                this.dispose();
                new Dashboard(userName, accNo);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
