import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class LoanStatus extends JFrame {
    private JTable loanTable;
    private DefaultTableModel model;
    private String accountNumber;

    public LoanStatus(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("Your Loan Status");
        setSize(700, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[] {
                "Loan Type", "Amount", "Tenure (months)", "Rate (%)", "EMI (₹)", "Status", "Requested On"
        });

        loanTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(loanTable);
        add(scrollPane, BorderLayout.CENTER);

        loadLoans();
        setVisible(true);
    }

    private void loadLoans() {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Loans WHERE account_number = ?");
            ps.setString(1, accountNumber);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getString("loan_type"),
                        rs.getDouble("amount"),
                        rs.getInt("tenure_months"),
                        rs.getFloat("interest_rate"),
                        rs.getDouble("emi"),
                        rs.getString("status"),
                        rs.getString("request_date")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading loan data: " + e.getMessage());
        }
    }
}
