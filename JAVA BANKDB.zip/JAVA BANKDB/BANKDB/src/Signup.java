import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;
import com.toedter.calendar.JDateChooser; // Date chooser component
import java.util.Date;
import java.text.SimpleDateFormat;

public class Signup extends JFrame {

    JTextField nameField, emailField, phoneField, addressField, aadharField, panField;
    JPasswordField passwordField;
    JComboBox<String> genderBox;
    JDateChooser dobChooser;
    JButton submitBtn, backBtn;

    public Signup() {
        setTitle("Create New Account - FinTechBank");
        setSize(520, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 245, 255));

        // Header
        JLabel header = new JLabel("Create Your FinTechBank Account", JLabel.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.setForeground(new Color(0, 102, 204));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        mainPanel.add(header, BorderLayout.NORTH);

        // Form panel
        JPanel form = new JPanel(new GridLayout(12, 2, 12, 12));
        form.setBorder(BorderFactory.createEmptyBorder(25, 40, 25, 40));
        form.setBackground(new Color(255, 255, 255));

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 15);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

        form.add(label("Full Name:", labelFont));
        nameField = textField(fieldFont); form.add(nameField);

        form.add(label("Gender:", labelFont));
        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderBox.setFont(fieldFont); form.add(genderBox);

        form.add(label("Email:", labelFont));
        emailField = textField(fieldFont); form.add(emailField);

        form.add(label("Phone:", labelFont));
        phoneField = textField(fieldFont); form.add(phoneField);

        form.add(label("Address:", labelFont));
        addressField = textField(fieldFont); form.add(addressField);

        form.add(label("DOB:", labelFont));
        dobChooser = new JDateChooser();
        dobChooser.setDateFormatString("yyyy-MM-dd");
        dobChooser.setFont(fieldFont);
        form.add(dobChooser);

        form.add(label("Aadhar Number:", labelFont));
        aadharField = textField(fieldFont); form.add(aadharField);

        form.add(label("PAN Number:", labelFont));
        panField = textField(fieldFont); form.add(panField);

        form.add(label("Password:", labelFont));
        passwordField = new JPasswordField();
        passwordField.setFont(fieldFont);
        form.add(passwordField);

        // Submit button
        form.add(new JLabel("")); // empty
        submitBtn = new JButton("Create Account");
        styleButton(submitBtn, new Color(0, 120, 215));
        submitBtn.addActionListener(e -> insertUser());
        form.add(submitBtn);

        // Back to login
        form.add(new JLabel("Already have an account?"));
        backBtn = new JButton("Back to Login");
        styleButton(backBtn, new Color(100, 100, 100));
        backBtn.addActionListener(e -> {
            dispose();
            new Login();
        });
        form.add(backBtn);

        mainPanel.add(form, BorderLayout.CENTER);
        add(mainPanel);
        setVisible(true);
    }

    private JLabel label(String text, Font font) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(font);
        return lbl;
    }

    private JTextField textField(Font font) {
        JTextField tf = new JTextField();
        tf.setFont(font);
        return tf;
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(bg.darker()));
    }

    private void insertUser() {
        String accountNumber = "ACC" + new Random().nextInt(99999999);
        String name = nameField.getText();
        String gender = (String) genderBox.getSelectedItem();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String address = addressField.getText();
        java.util.Date selectedDate = dobChooser.getDate();        java.sql.Date sqlDob = new java.sql.Date(selectedDate.getTime());
        String aadhar = aadharField.getText();
        String pan = panField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO Users (full_name, gender, email, phone, address, dob, aadhar, pan, password, account_number) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, gender);
            ps.setString(3, email);
            ps.setString(4, phone);
            ps.setString(5, address);
            ps.setDate(6, sqlDob);
            ps.setString(7, aadhar);
            ps.setString(8, pan);
            ps.setString(9, password);
            ps.setString(10, accountNumber);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Account Created!\nAccount No: " + accountNumber);
                this.dispose();
                new Login();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Signup();
    }
}
