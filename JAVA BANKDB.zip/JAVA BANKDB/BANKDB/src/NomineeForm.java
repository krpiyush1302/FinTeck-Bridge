import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class NomineeForm extends JFrame {
    private final String accountNumber;

    public NomineeForm(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("Add / Update Nominee");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel nameLabel = new JLabel("Nominee Name:");
        JTextField nameField = new JTextField();

        JLabel relationLabel = new JLabel("Relationship:");
        JTextField relationField = new JTextField();

        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        JTextField dobField = new JTextField();

        JLabel contactLabel = new JLabel("Contact (Phone/Email):");
        JTextField contactField = new JTextField();

        JButton saveBtn = new JButton("Save Nominee");
        JButton cancelBtn = new JButton("Cancel");

        saveBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String relation = relationField.getText().trim();
            String dob = dobField.getText().trim();
            String contact = contactField.getText().trim();

            if (name.isEmpty() || relation.isEmpty() || dob.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }

            try (Connection con = DBConnection.getConnection()) {
                String check = "SELECT * FROM Nominees WHERE account_number = ?";
                PreparedStatement checkStmt = con.prepareStatement(check);
                checkStmt.setString(1, accountNumber);
                ResultSet rs = checkStmt.executeQuery();

                String sql;
                if (rs.next()) {
                    sql = "UPDATE Nominees SET name=?, relationship=?, dob=?, contact=? WHERE account_number=?";
                } else {
                    sql = "INSERT INTO Nominees (name, relationship, dob, contact, account_number) VALUES (?, ?, ?, ?, ?)";
                }

                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, relation);
                ps.setString(3, dob);
                ps.setString(4, contact);
                ps.setString(5, accountNumber);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Nominee saved successfully!");
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving nominee: " + ex.getMessage());
            }
        });

        cancelBtn.addActionListener(e -> dispose());

        panel.add(nameLabel); panel.add(nameField);
        panel.add(relationLabel); panel.add(relationField);
        panel.add(dobLabel); panel.add(dobField);
        panel.add(contactLabel); panel.add(contactField);
        panel.add(saveBtn); panel.add(cancelBtn);

        add(panel);
        setVisible(true);
    }
}
