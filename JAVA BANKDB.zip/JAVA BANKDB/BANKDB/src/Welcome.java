import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.*;

public class Welcome extends JFrame {
    private final JTextArea chatArea;
    private final JTextField userInput;

    public Welcome() {
        setTitle("Welcome to FinTechBank Services");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(1, 2));

        // Left side panel for login/signup
        JPanel leftPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(58, 123, 213);
                Color color2 = new Color(0, 210, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel title = new JLabel("\uD83C\uDFE6 Welcome to FintechBank Portal");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel infoLabel = new JLabel("Secure. Fast. Simple.");
        infoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoLabel.setForeground(Color.WHITE);
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 30, 0));

        JButton loginBtn = new JButton("Login to Your Account");
        styleButton(loginBtn, new Color(255, 87, 34));

        JLabel orLabel = new JLabel("New user? Signup here:");
        orLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        orLabel.setForeground(Color.WHITE);
        orLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        orLabel.setBorder(BorderFactory.createEmptyBorder(25, 0, 10, 0));

        JButton signupBtn = new JButton("Create New Account");
        styleButton(signupBtn, new Color(76, 175, 80));

        loginBtn.addActionListener(e -> {
            dispose();
            new Login();
        });

        signupBtn.addActionListener(e -> {
            dispose();
            new Signup();
        });

        leftPanel.add(title);
        leftPanel.add(infoLabel);
        leftPanel.add(loginBtn);
        leftPanel.add(orLabel);
        leftPanel.add(signupBtn);

        // Right side panel for chatbot
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("\uD83E\uDD16 Ask FINBOT"));

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        JPanel inputPanel = new JPanel(new BorderLayout());
        userInput = new JTextField();
        JButton sendButton = new JButton("Ask");

        inputPanel.add(userInput, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        sendButton.addActionListener(e -> sendMessage());
        userInput.addActionListener(e -> sendMessage());

        rightPanel.add(scrollPane, BorderLayout.CENTER);
        rightPanel.add(inputPanel, BorderLayout.SOUTH);

        chatArea.append("\uD83E\uDD16 FINBOT: Hello! Ask me anything about the bank or how to create an account.\n");

        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        add(mainPanel);
        setVisible(true);
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setMaximumSize(new Dimension(220, 40));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    private void sendMessage() {
        String message = userInput.getText().trim();
        if (!message.isEmpty()) {
            chatArea.append("You: " + message + "\n");
            String reply = askOpenAI(message);
            chatArea.append("\uD83E\uDD16 FINBOT: " + reply + "\n");
            userInput.setText("");
        }
    }

    private String askOpenAI(String userMessage) {
        String apiKey = "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";
        String endpoint = "https://openrouter.ai/api/v1/chat/completions";

        try {
            HttpURLConnection conn = getHttpURLConnection(userMessage, endpoint, apiKey);

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line.trim());
                }
                return extractMessage(response.toString());
            }

        } catch (Exception e) {
            return "❌ Error contacting OpenRouter: " + e.getMessage();
        }
    }

    private static HttpURLConnection getHttpURLConnection(String userMessage, String endpoint, String apiKey) throws IOException {
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        String payload = "{" +
                "\"model\": \"openai/gpt-3.5-turbo\"," +
                "\"messages\": [{\"role\": \"user\", \"content\": \"" + userMessage + "\"}]}";

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = payload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        return conn;
    }

    private String extractMessage(String jsonResponse) {
        try {
            JSONObject obj = new JSONObject(jsonResponse);
            return obj.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content");
        } catch (JSONException e) {
            return "❌ Error parsing response.";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Welcome::new);
    }
}
