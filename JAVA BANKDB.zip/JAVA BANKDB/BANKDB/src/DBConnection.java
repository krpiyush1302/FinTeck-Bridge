import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        try {
            // Load SQL Server JDBC driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // JDBC URL for Windows Authentication
            String url = "jdbc:sqlserver://localhost:1433;databaseName=BankDB;integratedSecurity=true;trustServerCertificate=true\n";

            // Return the DB connection
            Connection conn = DriverManager.getConnection(url);
           return conn;
        } catch (Exception e) {
            // Print any errors for debugging
            e.printStackTrace();
            return null;
        }
    }
}
