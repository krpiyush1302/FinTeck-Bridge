import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class IMPS {
    public IMPS(String senderAccount) {
        String receiver = JOptionPane.showInputDialog("Enter receiver account number:");
        String amountStr = JOptionPane.showInputDialog("Enter amount to transfer (IMPS):");

        if (receiver == null || amountStr == null) return;

        try (Connection con = DBConnection.getConnection()) {
            double amount = Double.parseDouble(amountStr);
            if (amount <= 0) throw new NumberFormatException();

            // Check sender balance
            PreparedStatement check = con.prepareStatement("SELECT balance FROM Users WHERE account_number = ?");
            check.setString(1, senderAccount);
            ResultSet rs = check.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "Sender account not found.");
                return;
            }

            double balance = rs.getDouble("balance");
            if (balance < amount) {
                JOptionPane.showMessageDialog(null, "Insufficient balance.");
                return;
            }

            // Deduct from sender
            PreparedStatement deduct = con.prepareStatement("UPDATE Users SET balance = balance - ? WHERE account_number = ?");
            deduct.setDouble(1, amount);
            deduct.setString(2, senderAccount);
            deduct.executeUpdate();

            // Credit to receiver
            PreparedStatement credit = con.prepareStatement("UPDATE Users SET balance = balance + ? WHERE account_number = ?");
            credit.setDouble(1, amount);
            credit.setString(2, receiver);
            int rowsAffected = credit.executeUpdate();

            if (rowsAffected == 0) {
                JOptionPane.showMessageDialog(null, "Receiver account not found. Refunding sender...");
                // Refund sender
                PreparedStatement refund = con.prepareStatement("UPDATE Users SET balance = balance + ? WHERE account_number = ?");
                refund.setDouble(1, amount);
                refund.setString(2, senderAccount);
                refund.executeUpdate();
                return;
            }

            // Log transaction
            PreparedStatement log = con.prepareStatement(
                    "INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, 'Transfer', ?, 'IMPS to " + receiver + "')");
            log.setString(1, senderAccount);
            log.setDouble(2, amount);
            log.executeUpdate();

            JOptionPane.showMessageDialog(null, "✅ IMPS Transfer Successful!");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid amount.");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "❌ Error: " + e.getMessage());
        }
    }
}
