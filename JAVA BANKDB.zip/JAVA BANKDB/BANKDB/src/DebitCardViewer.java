import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.Random;

public class DebitCardViewer extends JFrame {
    private String accountNumber;
    private String cardHolder;

    public DebitCardViewer(String accountNumber, String cardHolder) {
        this.accountNumber = accountNumber;
        this.cardHolder = cardHolder;

        setTitle("Virtual Debit Card");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new GridLayout(4, 1));
        cardPanel.setBackground(new Color(0, 70, 140));
        cardPanel.setForeground(Color.WHITE);
        cardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel numberLabel = new JLabel();
        JLabel nameLabel = new JLabel();
        JLabel expiryLabel = new JLabel();
        JLabel cvvLabel = new JLabel();

        numberLabel.setForeground(Color.WHITE);
        nameLabel.setForeground(Color.WHITE);
        expiryLabel.setForeground(Color.WHITE);
        cvvLabel.setForeground(Color.WHITE);

        numberLabel.setFont(new Font("Monospaced", Font.BOLD, 16));
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        expiryLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        cvvLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        cardPanel.add(numberLabel);
        cardPanel.add(nameLabel);
        cardPanel.add(expiryLabel);
        cardPanel.add(cvvLabel);

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement check = con.prepareStatement("SELECT * FROM Cards WHERE account_number = ?");
            check.setString(1, accountNumber);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                // Already issued
                numberLabel.setText("Card No: " + rs.getString("card_number"));
                nameLabel.setText("Holder: " + rs.getString("card_holder_name"));
                expiryLabel.setText("Expiry: " + rs.getDate("expiry_date"));
                cvvLabel.setText("CVV: " + rs.getString("cvv"));
            } else {
                // Issue new card
                String cardNumber = generateCardNumber();
                LocalDate expiry = LocalDate.now().plusYears(5);
                String cvv = String.format("%03d", new Random().nextInt(999));

                PreparedStatement insert = con.prepareStatement("INSERT INTO Cards (account_number, card_number, card_holder_name, expiry_date, cvv) VALUES (?, ?, ?, ?, ?)");
                insert.setString(1, accountNumber);
                insert.setString(2, cardNumber);
                insert.setString(3, cardHolder);
                insert.setDate(4, Date.valueOf(expiry));
                insert.setString(5, cvv);
                insert.executeUpdate();

                numberLabel.setText("Card No: " + cardNumber);
                nameLabel.setText("Holder: " + cardHolder);
                expiryLabel.setText("Expiry: " + expiry);
                cvvLabel.setText("CVV: " + cvv);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }

        add(cardPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private String generateCardNumber() {
        StringBuilder sb = new StringBuilder();
        Random r = new Random();
        for (int i = 0; i < 4; i++) {
            sb.append(String.format("%04d", r.nextInt(10000)));
            if (i < 3) sb.append(" ");
        }
        return sb.toString();
    }
}
