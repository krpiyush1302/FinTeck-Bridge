import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.MessageDigest;
import java.sql.*;

public class SetUpiPin extends JFrame {
    private final JPasswordField pinField;
    private final String accountNumber;

    public SetUpiPin(String accountNumber) {
        this.accountNumber = accountNumber;
        setTitle("Set / Change UPI PIN");
        setSize(300, 150);
        setLocationRelativeTo(null);

        JLabel pinLabel = new JLabel("Enter New UPI PIN:");
        pinField = new JPasswordField(10);
        JButton setPinButton = new JButton("Set PIN");

        setPinButton.addActionListener(e -> savePin());

        JPanel panel = new JPanel(new GridLayout(3, 1));
        panel.add(pinLabel);
        panel.add(pinField);
        panel.add(setPinButton);
        add(panel);
        setVisible(true);
    }

    private void savePin() {
        String pin = new String(pinField.getPassword()).trim();
        if (pin.length() < 4 || pin.length() > 6 || !pin.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "PIN must be 4–6 digits.");
            return;
        }

        String hashedPin = hashUPIPin(pin);
        try (Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=BankDB;integratedSecurity=true;encrypt=true;trustServerCertificate=true")) {
            PreparedStatement ps = con.prepareStatement("UPDATE Users SET upi_pin_hash = ? WHERE account_number = ?");
            ps.setString(1, hashedPin);
            ps.setString(2, accountNumber);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "UPI PIN set successfully!");
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private String hashUPIPin(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(pin.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
