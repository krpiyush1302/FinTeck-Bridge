import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ServiceRequestCenter extends JFrame {

    private JComboBox<String> requestTypeBox;
    private JTextArea messageArea;
    private JButton submitBtn;
    private String accountNumber;

    public ServiceRequestCenter(String accountNumber) {
        this.accountNumber = accountNumber;

        setTitle("Service Request Center");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        JLabel typeLabel = new JLabel("Select Request Type:");
        requestTypeBox = new JComboBox<>(new String[]{
                "Passbook Request",
                "Checkbook Request",
                "Unable to Withdraw",
                "Account Issue",
                "Other"
        });

        JLabel msgLabel = new JLabel("Description / Message:");
        messageArea = new JTextArea(4, 20);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(messageArea);

        submitBtn = new JButton("Submit Request");
        submitBtn.setBackground(new Color(0, 120, 215));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.addActionListener(e -> submitRequest());

        formPanel.add(typeLabel);
        formPanel.add(requestTypeBox);
        formPanel.add(msgLabel);
        formPanel.add(scroll);
        formPanel.add(submitBtn);

        add(formPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private void submitRequest() {
        String type = (String) requestTypeBox.getSelectedItem();
        String msg = messageArea.getText();

        if (msg.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a message.");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO ServiceRequests (account_number, request_type, message) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, accountNumber);
            ps.setString(2, type);
            ps.setString(3, msg);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Request submitted. You'll be contacted shortly.");
                this.dispose();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}
