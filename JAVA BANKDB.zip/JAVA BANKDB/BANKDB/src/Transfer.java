import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Transfer extends JFrame {
    private String senderAccount;
    private JTextField recipientField, amountField;
    private Dashboard dashboard; // ✅ Reference to dashboard

    // ✅ Modified constructor to accept Dashboard
    public Transfer(String senderAccount, Dashboard dashboard) {
        this.senderAccount = senderAccount;
        this.dashboard = dashboard;

        setTitle("Transfer Funds");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Recipient Account No:"));
        recipientField = new JTextField();
        panel.add(recipientField);

        panel.add(new JLabel("Amount to Transfer:"));
        amountField = new JTextField();
        panel.add(amountField);

        JButton transferBtn = new JButton("Transfer");
        transferBtn.addActionListener(e -> performTransfer());
        panel.add(transferBtn);

        add(panel);
        setVisible(true);
    }

    private void performTransfer() {
        String recipient = recipientField.getText();
        try {
            double amount = Double.parseDouble(amountField.getText());

            try (Connection con = DBConnection.getConnection()) {
                con.setAutoCommit(false); // Start transaction

                // Check sender balance
                PreparedStatement check = con.prepareStatement(
                        "SELECT balance FROM Users WHERE account_number = ?");
                check.setString(1, senderAccount);
                ResultSet rs = check.executeQuery();

                if (rs.next() && rs.getDouble("balance") >= amount) {
                    // Deduct from sender
                    PreparedStatement deduct = con.prepareStatement(
                            "UPDATE Users SET balance = balance - ? WHERE account_number = ?");
                    deduct.setDouble(1, amount);
                    deduct.setString(2, senderAccount);
                    deduct.executeUpdate();

                    // Add to recipient
                    PreparedStatement credit = con.prepareStatement(
                            "UPDATE Users SET balance = balance + ? WHERE account_number = ?");
                    credit.setDouble(1, amount);
                    credit.setString(2, recipient);
                    int updated = credit.executeUpdate();

                    if (updated == 0) {
                        con.rollback();
                        JOptionPane.showMessageDialog(this, "Recipient account not found.");
                        return;
                    }

                    // Log transactions
                    PreparedStatement tr1 = con.prepareStatement(
                            "INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, 'Transfer', ?, ?)");
                    tr1.setString(1, senderAccount);
                    tr1.setDouble(2, amount);
                    tr1.setString(3, "Transferred to " + recipient);
                    tr1.executeUpdate();

                    PreparedStatement tr2 = con.prepareStatement(
                            "INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, 'Deposit', ?, ?)");
                    tr2.setString(1, recipient);
                    tr2.setDouble(2, amount);
                    tr2.setString(3, "Received from " + senderAccount);
                    tr2.executeUpdate();

                    con.commit();

                    // ✅ Refresh dashboard balance
                    if (dashboard != null) {
                        dashboard.updateBalance();
                    }

                    JOptionPane.showMessageDialog(this, "Transfer Successful!");
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Insufficient Balance!");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid amount.");
        }
    }
}
