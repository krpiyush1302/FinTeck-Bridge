import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BillPayment extends JFrame {
    private JComboBox<String> billTypeBox;
    private JTextField payeeField, amountField;
    private JButton payBtn;
    private String accountNumber;
    private Runnable refreshCallback; // ✅ Add this


    public BillPayment(String accountNumber, Runnable refreshCallback) {
        this.accountNumber = accountNumber;
        this.refreshCallback = refreshCallback; // ✅ Save callback

        setTitle("Bill Payment");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        billTypeBox = new JComboBox<>(new String[]{"Electricity", "Internet", "Water", "Phone"});
        payeeField = new JTextField();
        amountField = new JTextField();

        payBtn = new JButton("Pay Now");
        payBtn.setBackground(new Color(0, 120, 215));
        payBtn.setForeground(Color.WHITE);
        payBtn.addActionListener(e -> makePayment());

        panel.add(new JLabel("Bill Type:"));
        panel.add(billTypeBox);
        panel.add(new JLabel("Payee Name:"));
        panel.add(payeeField);
        panel.add(new JLabel("Amount:"));
        panel.add(amountField);
        panel.add(new JLabel(""));
        panel.add(payBtn);

        add(panel);
        setVisible(true);
    }

    private void makePayment() {
        String billType = (String) billTypeBox.getSelectedItem();
        String payee = payeeField.getText();
        double amount = Double.parseDouble(amountField.getText());

        try (Connection con = DBConnection.getConnection()) {
            // Check current balance
            PreparedStatement checkBal = con.prepareStatement("SELECT balance FROM Users WHERE account_number = ?");
            checkBal.setString(1, accountNumber);
            ResultSet rs = checkBal.executeQuery();

            if (rs.next()) {
                double currentBal = rs.getDouble("balance");
                if (currentBal >= amount) {
                    // Deduct balance
                    PreparedStatement updateBal = con.prepareStatement("UPDATE Users SET balance = balance - ? WHERE account_number = ?");
                    updateBal.setDouble(1, amount);
                    updateBal.setString(2, accountNumber);
                    updateBal.executeUpdate();

                    // Record bill payment
                    PreparedStatement record = con.prepareStatement("INSERT INTO BillPayments(account_number, bill_type, payee_name, amount) VALUES (?, ?, ?, ?)");
                    record.setString(1, accountNumber);
                    record.setString(2, billType);
                    record.setString(3, payee);
                    record.setDouble(4, amount);
                    record.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Payment Successful!");
                    if (refreshCallback != null) refreshCallback.run(); // ✅ Update balance
                    dispose();

                } else {
                    JOptionPane.showMessageDialog(this, "Insufficient balance.");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}
