import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.time.LocalTime;
import org.json.*;

public class ChatBot extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private String accountNumber;
    private String userName;
    private JSONArray messageHistory = new JSONArray();

    public ChatBot(String accountNumber, String userName) {
        this.accountNumber = accountNumber;
        this.userName = userName;

        setTitle("FINBANK ChatBot");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        inputField = new JTextField();
        inputField.addActionListener(e -> respond());

        JButton sendBtn = new JButton("Send");
        sendBtn.addActionListener(e -> respond());

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendBtn, BorderLayout.EAST);

        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        welcome();
        setVisible(true);

        // Prime GPT context
        messageHistory.put(new JSONObject().put("role", "system")
                .put("content", "You are a helpful banking assistant. Answer questions about account, balance, transactions, etc. Fetch real data if user asks."));
    }

    private void welcome() {
        String greeting;
        LocalTime now = LocalTime.now();
        if (now.isBefore(LocalTime.NOON)) greeting = "Good Morning";
        else if (now.isBefore(LocalTime.of(17, 0))) greeting = "Good Afternoon";
        else greeting = "Good Evening";

        chatArea.append("🤖 FINBOT: " + greeting + " " + userName + "! How can I assist you today?\n");
    }

    private void respond() {
        String userInput = inputField.getText().trim();
        if (userInput.isEmpty()) return;

        chatArea.append("👤 You: " + userInput + "\n");
        inputField.setText("");

        // First check for database-backed intent
        String intentResponse = analyzeUserIntent(userInput);
        if (intentResponse != null) {
            chatArea.append("🤖 ChatBot: " + intentResponse + "\n");
            return;
        }

        // Fallback to GPT
        messageHistory.put(new JSONObject().put("role", "user").put("content", userInput));
        String reply = askOpenRouterWithMemory();
        chatArea.append("🤖 FINBOT: " + reply + "\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private String analyzeUserIntent(String message) {
        String lower = message.toLowerCase();

        try (Connection conn = DBConnection.getConnection()) {
            if (lower.contains("account number")) {
                return "Your account number is: XXXXXX" + accountNumber.substring(accountNumber.length() - 8);
            }

            if (lower.contains("balance") || lower.contains("current balance") || lower.contains("current amount") || lower.contains("current funds") || lower.contains("current amount in account") || lower.contains("current funds in account") ) {
                assert conn != null;
                PreparedStatement ps = conn.prepareStatement("SELECT balance FROM Users WHERE account_number = ?");
                ps.setString(1, accountNumber);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    double balance = rs.getDouble("balance");
                    return "Your current balance is ₹" + balance;
                } else {
                    return "Could not retrieve your balance at the moment.";
                }
            }

            if (lower.contains("last transaction")) {
                assert conn != null;
                PreparedStatement ps = conn.prepareStatement("SELECT TOP 1 * FROM Transactions WHERE account_number = ? ORDER BY date DESC");
                ps.setString(1, accountNumber);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    String type = rs.getString("type");
                    double amt = rs.getDouble("amount");
                    Date date = rs.getDate("date");
                    return "Your last transaction was a " + type + " of ₹" + amt + " on " + date + ".";
                } else {
                    return "No recent transactions found.";
                }
            }

            if (lower.contains("fd") || lower.contains("fixed deposit")|| lower.contains("fixed deposits") || lower.contains("my fixed deposits") || lower.contains("my fixed deposit")||lower.contains("fds")  ) {
                assert conn != null;
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM FixedDeposits WHERE account_number = ?");
                ps.setString(1, accountNumber);
                ResultSet rs = ps.executeQuery();
                StringBuilder sb = new StringBuilder();
                while (rs.next()) {
                    sb.append("FD ₹").append(rs.getDouble("amount"))
                            .append(" | Start: ").append(rs.getDate("start_date"))
                            .append(" | Tenure: ").append(rs.getInt("tenure_months")).append(" months")
                            .append(" | Rate: ").append(rs.getDouble("interest_rate")).append("%")
                            .append(" | Maturity: ₹").append(rs.getDouble("maturity_amount"))
                            .append(" on ").append(rs.getDate("maturity_date"))
                            .append("\n");
                }

                if (!sb.isEmpty()) return sb.toString();
                else return "You have no fixed deposits currently.";
            }

        } catch (SQLException e) {
            return "⚠️ Error connecting to database: " + e.getMessage();
        }

        return null;
    }

    private String askOpenRouterWithMemory() {
        String apiKey = "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";
        String endpoint = "https://openrouter.ai/api/v1/chat/completions";

        for (int attempt = 0; true; attempt++) {
            try {
                URL url = new URL(endpoint);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                JSONObject payload = new JSONObject();
                payload.put("model", "openai/gpt-3.5-turbo");
                payload.put("messages", messageHistory);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }

                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) response.append(line.trim());

                    JSONObject json = new JSONObject(response.toString());
                    String reply = json.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content");

                    messageHistory.put(new JSONObject().put("role", "assistant").put("content", reply));
                    return reply;
                }

            } catch (Exception e) {
                if (attempt == 1)
                    return "⚠️ GPT is currently unavailable. Please try again later.";
            }
        }

//        return "⚠️ Unexpected error occurred.";
    }
}
