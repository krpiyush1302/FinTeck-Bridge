import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RTGSTransfer extends JFrame {
    public RTGSTransfer(String senderAccNo, Runnable onTransferSuccess) {
        setTitle("RTGS Transfer");
        setSize(400, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField nameField = new JTextField();
        JTextField accField = new JTextField();
        JTextField ifscField = new JTextField();
        JTextField amtField = new JTextField();
        JTextField remarksField = new JTextField();

        panel.add(new JLabel("Beneficiary Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Account Number:"));
        panel.add(accField);
        panel.add(new JLabel("IFSC Code:"));
        panel.add(ifscField);
        panel.add(new JLabel("Amount (₹):"));
        panel.add(amtField);
        panel.add(new JLabel("Remarks:"));
        panel.add(remarksField);

        JButton submitBtn = new JButton("Transfer");
        panel.add(new JLabel()); // Empty cell
        panel.add(submitBtn);

        submitBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String toAcc = accField.getText().trim();
            String ifsc = ifscField.getText().trim();
            String amtStr = amtField.getText().trim();
            String remarks = remarksField.getText().trim();

            if (name.isEmpty() || toAcc.isEmpty() || ifsc.isEmpty() || amtStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
                return;
            }

            try {
                double amount = Double.parseDouble(amtStr);
                if (amount < 200000) {
                    JOptionPane.showMessageDialog(this, "RTGS is only allowed for ₹2,00,000 and above.");
                    return;
                }

                try (Connection con = DBConnection.getConnection()) {
                    con.setAutoCommit(false);

                    PreparedStatement checkBal = con.prepareStatement("SELECT balance FROM Users WHERE account_number=?");
                    checkBal.setString(1, senderAccNo);
                    ResultSet rs = checkBal.executeQuery();
                    if (!rs.next() || rs.getDouble("balance") < amount) {
                        JOptionPane.showMessageDialog(this, "Insufficient Balance.");
                        return;
                    }

                    // Deduct from sender
                    PreparedStatement deduct = con.prepareStatement("UPDATE Users SET balance = balance - ? WHERE account_number = ?");
                    deduct.setDouble(1, amount);
                    deduct.setString(2, senderAccNo);
                    deduct.executeUpdate();

                    // Add to receiver
                    PreparedStatement add = con.prepareStatement("UPDATE Users SET balance = balance + ? WHERE account_number = ?");
                    add.setDouble(1, amount);
                    add.setString(2, toAcc);
                    add.executeUpdate();

                    // Log transaction
                    PreparedStatement tx = con.prepareStatement("INSERT INTO Transactions (account_number, type, amount, description) VALUES (?, ?, ?, ?)");
                    tx.setString(1, senderAccNo);
                    tx.setString(2, "RTGS");
                    tx.setDouble(3, amount);
                    tx.setString(4, "To: " + toAcc + ", IFSC: " + ifsc + ", " + remarks);
                    tx.executeUpdate();

                    con.commit();

                    JOptionPane.showMessageDialog(this, "RTGS Transfer Successful.");
                    dispose();
                    onTransferSuccess.run(); // Update balance in dashboard
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Transfer failed: " + ex.getMessage());
            }
        });

        add(panel);
        setVisible(true);
    }
}

