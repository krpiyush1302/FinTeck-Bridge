import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class MiniStatement extends JFrame {
    private String accountNumber;

    public MiniStatement(String accountNumber) {
        this.accountNumber = accountNumber;

        setTitle("Mini Statement");
        setSize(600, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = { "Date/Time", "Type", "Amount", "Description" };
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);

        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT TOP 10 date_time, type, amount, description FROM Transactions " +
                    "WHERE account_number = ? ORDER BY date_time DESC";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, accountNumber);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String dateTime = rs.getString("date_time");
                String type = rs.getString("type");
                String amount = "₹" + rs.getDouble("amount");
                String desc = rs.getString("description");
                model.addRow(new Object[] { dateTime, type, amount, desc });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error fetching statement: " + e.getMessage());
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane);
        setVisible(true);
    }
}
